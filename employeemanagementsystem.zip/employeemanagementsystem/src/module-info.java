/**
 * 
 */
/**
 * 
 */
module employeemanagementsystem {
	requires java.sql;
}